import { $ } from "./dom.js";
import { store } from "./storage.js";
import { sanitizeText } from "../logic.js";

/** Shows the login dialog and resolves with { token, name, role } after the server accepts it. */
export function login() {
  const dlg = $("#loginDlg"), form = $("#loginF"), err = $("#loginErr");
  dlg.addEventListener("cancel", e => e.preventDefault());
  dlg.showModal();
  return new Promise(resolve => {
    form.addEventListener("submit", async e => {
      e.preventDefault();
      err.textContent = "";
      const name = sanitizeText($("#loginName").value, 24), password = $("#loginPw").value;
      if (name.length < 2) { err.textContent = "Please enter a name (at least 2 characters)."; return; }
      try {
        const res = await fetch("/api/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, password }) });
        const data = await res.json();
        if (!res.ok) { err.textContent = data.error || "Login failed."; return; }
        store.set("ll_session", data);
        dlg.close();
        resolve(data);
      } catch { err.textContent = "Cannot reach the server. Try again."; }
    });
  });
}

export function logout() { store.remove("ll_session"); location.reload(); }
