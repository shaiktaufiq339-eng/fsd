// Sample data for "Global Tech Summit 2026" (speaker names are fictional placeholders).
const MIN = 60000;
export const EVENT = { id: "gts2026", title: "Global Tech Summit 2026" };

const RAW = [
  { title: "The AI Revolution", speaker: "Dr. Aisha Rahman", role: "AI Research Lead", bio: "Studies agentic AI systems and how to keep them auditable.", from: -20, to: 25 },
  { title: "Cloud Computing at Scale", speaker: "Marcus Chen", role: "Cloud Architect", bio: "Designs multi-region platforms for global streaming workloads.", from: 45, to: 90 },
  { title: "Quantum Algorithms", speaker: "Dr. Elena Petrova", role: "Quantum Scientist", bio: "Works on error correction and near-term quantum advantage.", from: 95, to: 140 },
  { title: "Web3 Security", speaker: "Samuel Okafor", role: "Security Engineer", bio: "Audits smart contracts and studies real-world exploit patterns.", from: 145, to: 190 },
];
export const sessions = RAW.map(s => ({ ...s, start: Date.now() + s.from * MIN, end: Date.now() + s.to * MIN }));
export const statusOf = (s, now = Date.now()) => (now >= s.end ? "done" : now >= s.start ? "live" : "up");

export const SEED = {
  questions: [
    ["How should small teams adopt AI safely?", 24], ["Is multi-cloud worth the operational complexity?", 17],
    ["What is the realistic timeline for Quantum Error Correction at scale?", 11],
    ["Which Web3 attack vector is most underestimated?", 6], ["Will the slides be shared after the session?", 3],
  ],
  poll: { q: "What is your primary cloud provider?", o: [["AWS", 42], ["Azure", 31], ["Google Cloud", 19], ["Other", 8]] },
  botNames: ["Priya", "Tomás", "Mei", "Jonas", "Amara", "Liam", "Sofia", "Kenji"],
  botLines: ["Hello from Hyderabad! 👋", "This keynote is so good", "Anyone else taking notes?", "Great point on auditability",
    "Slides will be shared later, right?", "Greetings from Berlin", "The demo was impressive 🔥", "Love the hybrid format here",
    "Can someone explain that last slide?", "Watching on my phone, works great"],
};
