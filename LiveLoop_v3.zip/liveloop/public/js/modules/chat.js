import { $, h, clock } from "../core/dom.js";
import { sanitizeText, LIMITS } from "../logic.js";

export function init({ net, session }) {
  const list = $("#chat"), jump = $("#jump"), input = $("#chatI");
  const nearBottom = () => list.scrollHeight - list.scrollTop - list.clientHeight < 80;

  function add({ name, text }) {
    const mine = name === session.name, stick = nearBottom() || mine;
    list.append(h("div", { class: "msg" }, [h("b", { text: mine ? "You" : name }), h("time", { text: clock(new Date()) }), h("div", { text })]));
    while (list.children.length > 200) list.firstChild.remove(); // keep the DOM small
    if (stick) { list.scrollTop = list.scrollHeight; jump.style.display = "none"; } else jump.style.display = "block";
  }
  jump.addEventListener("click", () => { list.scrollTop = list.scrollHeight; jump.style.display = "none"; });
  list.addEventListener("scroll", () => { if (nearBottom()) jump.style.display = "none"; });

  let last = 0;
  $("#chatF").addEventListener("submit", e => {
    e.preventDefault();
    const text = sanitizeText(input.value, LIMITS.chat);
    if (!text || Date.now() - last < 800) return;
    last = Date.now(); input.value = "";
    net.sendChat(text);
  });
  net.on("init", ({ chat }) => { list.textContent = ""; chat.forEach(add); });
  net.on("chat", add);
}
