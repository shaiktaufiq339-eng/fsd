import {clean,percentages as pct,rankQuestions,parseEmbed} from "./logic.js";
var CID="c"+Math.random().toString(36).slice(2,10);
try{CID=localStorage.getItem("ll_cid")||CID;localStorage.setItem("ll_cid",CID)}catch(e){}
var MYNAME="Guest-"+CID.slice(-4),mineQ=new Set(),sock=null;
try{if(window.io)sock=io({auth:{cid:CID}})}catch(e){sock=null}
function toast(m){var t=document.createElement("div");t.className="toast";t.setAttribute("role","status");t.textContent=m;document.body.appendChild(t);setTimeout(function(){t.remove()},4000)}
window.addEventListener("error",function(){toast("Something went wrong, but LiveLoop is still running.")});
window.addEventListener("unhandledrejection",function(){toast("A request failed. Please try again.")});
var $=function(s){return document.querySelector(s)};
function h(tag,props,kids){var e=document.createElement(tag);for(var k in props||{}){if(k==="text")e.textContent=props[k];else if(k.slice(0,2)==="on")e.addEventListener(k.slice(2),props[k]);else e.setAttribute(k,props[k])}(kids||[]).forEach(function(c){e.appendChild(c)});return e}
var now=Date.now(),MIN=60000;
var sessions=[
{t:"The AI Revolution",s:"Dr. Aisha Rahman",r:"AI Research Lead",b:"Studies agentic AI systems and how to keep them auditable.",at:now-20*MIN,end:now+25*MIN},
{t:"Cloud Computing at Scale",s:"Marcus Chen",r:"Cloud Architect",b:"Designs multi-region platforms for global streaming workloads.",at:now+45*MIN,end:now+90*MIN},
{t:"Quantum Algorithms",s:"Dr. Elena Petrova",r:"Quantum Scientist",b:"Works on error correction and near-term quantum advantage.",at:now+95*MIN,end:now+140*MIN},
{t:"Web3 Security",s:"Samuel Okafor",r:"Security Engineer",b:"Audits smart contracts and studies real-world exploit patterns.",at:now+145*MIN,end:now+190*MIN}];
var cur=0;
var names=["Priya","Tomás","Mei","Jonas","Amara","Liam","Sofia","Kenji"];
var botLines=["Hello from Hyderabad! 👋","This keynote is so good","Anyone else taking notes?","Great point on auditability","Slides will be shared later, right?","Greetings from Berlin","The demo was impressive 🔥","Love the hybrid format here","Can someone explain that last slide?","Watching on my phone, works great"];

// ---- Player + session metadata
function fmt(ms){var s=Math.max(0,Math.floor(ms/1000)),p=function(n){return String(n).padStart(2,"0")};return p(Math.floor(s/3600))+":"+p(Math.floor(s%3600/60))+":"+p(s%60)}
function status(x){var n=Date.now();return n>=x.end?"done":n>=x.at?"live":"up"}
function renderNow(){var x=sessions[cur],st=status(x);
$("#simT").textContent=x.t;$("#simS").textContent=x.s+" · "+x.r;
$("#nowT").textContent=x.t;$("#nowS").textContent=x.s+" – "+x.r+". "+x.b;
var el=$("#nowSt");el.textContent=st==="live"?"Live now":st==="up"?"Starts in "+fmt(x.at-Date.now()):"Completed";
var nx=sessions[cur+1];$("#nowNext").textContent=nx?"Up next: "+nx.t+" in "+fmt(nx.at-Date.now()):"This is the final session.";}
$("#srcF").addEventListener("submit",function(e){e.preventDefault();var u=(parseEmbed($("#srcI").value)||{}).src,old=$("#player iframe");
if(old)old.remove();
if(!u){$("#sim").style.display="flex";$("#simS").textContent="Couldn’t read that link. Try a YouTube or Vimeo URL.";return}
$("#sim").style.display="none";var f=h("iframe",{src:u,allow:"autoplay; fullscreen; picture-in-picture",allowfullscreen:"",title:"Event livestream"});$("#player").insertBefore(f,$("#fx"))});

// ---- Schedule drawer
function renderSched(){var box=$("#sched");box.textContent="";
sessions.forEach(function(x,i){var st=status(x),open=i===cur;
var head=h("button",{"aria-expanded":open},[
h("span",{class:"st "+st,text:st==="live"?"Live":st==="up"?"Starts in "+fmt(x.at-Date.now()):"Completed"}),
h("b",{text:x.t}),h("span",{class:"chip",text:x.s+" · "+new Date(x.at).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})})]);
var body=h("div",{class:"body"},[h("p",{text:x.r+". "+x.b}),h("button",{class:"btn primary",text:"Watch this session",onclick:function(){cur=i;renderNow();renderSched();$("#drawer").classList.remove("on")}})]);
var card=h("div",{class:"sess"+(open?" open":"")},[head,body]);
head.addEventListener("click",function(){var o=!card.classList.contains("open");document.querySelectorAll(".sess").forEach(function(c){c.classList.remove("open");c.firstChild.setAttribute("aria-expanded","false")});if(o){card.classList.add("open");head.setAttribute("aria-expanded","true")}});
box.appendChild(card)})}
$("#schedBtn").onclick=function(){renderSched();$("#drawer").classList.add("on")};
$("#closeD").onclick=function(){$("#drawer").classList.remove("on")};
$("#themeBtn").onclick=function(){var d=document.documentElement,dark=getComputedStyle(d).colorScheme==="dark";d.setAttribute("data-theme",dark?"light":"dark")};
setInterval(function(){renderNow();if($("#drawer").classList.contains("on")){var o=document.querySelector(".sess.open");if(!o)renderSched()}},1000);

// ---- Tabs
document.querySelectorAll(".tabs button").forEach(function(b){b.onclick=function(){
document.querySelectorAll(".tabs button").forEach(function(x){x.setAttribute("aria-selected",x===b)});
document.querySelectorAll(".panel").forEach(function(p){p.classList.remove("on")});
$("#p-"+b.dataset.t).classList.add("on");if(b.dataset.t==="poll")$("#pdot").style.display="none"}});

// ---- Chat
var chat=$("#chat"),jump=$("#jump");
function atBottom(){return chat.scrollHeight-chat.scrollTop-chat.clientHeight<80}
function addMsg(n,t,me){var stick=atBottom()||me,d=new Date();
chat.appendChild(h("div",{class:"msg"},[h("b",{text:n}),h("time",{text:d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}),h("div",{text:t})]));
while(chat.children.length>200)chat.removeChild(chat.firstChild);
if(stick){chat.scrollTop=chat.scrollHeight;jump.style.display="none"}else jump.style.display="block"}
jump.onclick=function(){chat.scrollTop=chat.scrollHeight;jump.style.display="none"};
chat.addEventListener("scroll",function(){if(atBottom())jump.style.display="none"});
var lastSend=0;
$("#chatF").addEventListener("submit",function(e){e.preventDefault();var v=clean($("#chatI").value,200);if(!v||Date.now()-lastSend<800)return;lastSend=Date.now();$("#chatI").value="";if(sock)sock.emit("chat:send",{name:MYNAME,text:v});else addMsg("You",v,true)});
if(!sock)botLines.slice(0,4).forEach(function(l,i){addMsg(names[i],l)});
if(!sock)(function bot(){setTimeout(function(){addMsg(names[Math.floor(Math.random()*names.length)],botLines[Math.floor(Math.random()*botLines.length)]);bot()},4000+Math.random()*5000)})();

// ---- Q&A
var qs=[{t:"How should small teams adopt AI safely?",v:24},{t:"Is multi-cloud worth the operational complexity?",v:17},{t:"What is the realistic timeline for Quantum Error Correction at scale?",v:11},{t:"Which Web3 attack vector is most underestimated?",v:6},{t:"Will the slides be shared after the session?",v:3}].map(function(q,i){q.id=i;q.me=false;q.ts=i;return q});
function renderQ(){var box=$("#qList"),before={};
box.querySelectorAll(".q").forEach(function(e){before[e.dataset.id]=e.getBoundingClientRect().top});
qs=rankQuestions(qs);box.textContent="";
qs.forEach(function(q){var btn=h("button",{class:"up"+(q.me?" on":""),"aria-label":"Upvote question","aria-pressed":q.me,onclick:function(){if(sock){sock.emit("qna:vote",{id:q.id},function(r){if(r&&r.ok){if(r.voted)mineQ.add(q.id);else mineQ.delete(q.id);markMine()}})}else{q.me=!q.me;q.v+=q.me?1:-1;renderQ()}}},[h("span",{text:"▲"}),h("b",{text:q.v})]);
box.appendChild(h("div",{class:"q","data-id":q.id},[btn,h("p",{text:q.t})]))});
box.querySelectorAll(".q").forEach(function(e){var o=before[e.dataset.id];if(o==null)return;var dy=o-e.getBoundingClientRect().top;if(dy){e.style.transition="none";e.style.transform="translateY("+dy+"px)";requestAnimationFrame(function(){requestAnimationFrame(function(){e.style.transition="";e.style.transform=""})})}})}
$("#qF").addEventListener("submit",function(e){e.preventDefault();var v=clean($("#qI").value,280);if(!v)return;$("#qI").value="";
if(sock){sock.emit("qna:ask",{text:v},function(r){if(r&&r.id!=null){mineQ.add(r.id);markMine()}});return}
var dup=qs.filter(function(q){return q.t.toLowerCase()===v.toLowerCase()})[0];
if(dup){dup.me=true;dup.v++}else qs.push({id:qs.length+Math.random(),t:v,v:1,me:true,ts:qs.length});
renderQ()});
renderQ();

// ---- Polls
var poll={q:"What is your primary cloud provider?",o:[{l:"AWS",v:42},{l:"Azure",v:31},{l:"Google Cloud",v:19},{l:"Other",v:8}],mine:-1};
function renderPoll(el){var p=pct(poll.o.map(function(o){return o.v})),tot=poll.o.reduce(function(a,o){return a+o.v},0);el.textContent="";
el.appendChild(h("h3",{text:poll.q}));
poll.o.forEach(function(o,i){var bar=h("i");var b=h("button",{class:"opt"+(poll.mine===i?" mine":""),onclick:function(){if(poll.mine<0){if(sock){sock.emit("poll:vote",{i:i},function(r){if(r&&r.ok){poll.mine=i;renderAllPolls()}})}else{poll.mine=i;o.v++;renderAllPolls()}}}},[bar,h("span",{text:o.l}),h("span",{text:(poll.mine<0?"":p[i]+"% · ")+o.v})]);
if(poll.mine>=0){b.disabled=false;requestAnimationFrame(function(){bar.style.width=p[i]+"%"})}el.appendChild(b)});
el.appendChild(h("small",{class:"chip",text:poll.mine<0?"Vote to see live results · "+tot+" votes":"Thanks for voting · "+tot+" votes · results update live"}))}
function renderAllPolls(){renderPoll($("#pollBox"));if($("#pollDlg").open)renderPoll($("#pollPop"))}
setInterval(function(){if(sock||poll.mine<0)return;poll.o[Math.floor(Math.random()*poll.o.length)].v++;renderAllPolls()},2500);
renderAllPolls();
setTimeout(function(){$("#pdot").style.display="inline-block";renderPoll($("#pollPop"));if(!$("#pollDlg").open&&$("#pollDlg").showModal)$("#pollDlg").showModal()},15000);
$("#popClose").onclick=function(){$("#pollDlg").close()};

// ---- Reactions (canvas particles, pooled, capped)
var cv=$("#fx"),cx=cv.getContext("2d"),W=0,H=0,dpr=1,active=[],pool=[],running=false,last=0,sprites={};
var RX=[["👏","Clap"],["❤️","Heart"],["🔥","Fire"],["🤯","Mindblown"],["🚀","Rocket"]],counts={};
function sprite(e){if(sprites[e])return sprites[e];var c=document.createElement("canvas");c.width=c.height=64;var g=c.getContext("2d");g.font="48px serif";g.textAlign="center";g.textBaseline="middle";g.fillText(e,32,36);return sprites[e]=c}
function size(){var r=cv.getBoundingClientRect();dpr=window.devicePixelRatio||1;W=r.width;H=r.height;cv.width=W*dpr;cv.height=H*dpr}
new ResizeObserver(size).observe(cv);
var reduce=matchMedia("(prefers-reduced-motion:reduce)").matches;
function spawn(e,n,bx){for(var i=0;i<n;i++){if(active.length>=250)return;var p=pool.pop()||{};
p.e=e;p.x=bx+(Math.random()-.5)*60;p.y=H-20;p.vx=(Math.random()-.5)*80;p.vy=-(120+Math.random()*140);p.age=0;p.life=1.8+Math.random()*1.2;
p.rot=(Math.random()-.5);p.rs=(Math.random()-.5)*2;p.sc=.5+Math.random()*.6;p.ph=Math.random()*6;p.fq=3+Math.random()*3;active.push(p)}
if(!running){running=true;last=performance.now();requestAnimationFrame(frame)}}
function frame(t){var dt=Math.min((t-last)/1000,.05);last=t;cx.setTransform(dpr,0,0,dpr,0,0);cx.clearRect(0,0,W,H);
for(var i=active.length-1;i>=0;i--){var p=active[i];p.age+=dt;if(p.age>=p.life){pool.push(active.splice(i,1)[0]);continue}
p.x+=(p.vx+Math.sin(p.age*p.fq+p.ph)*40)*dt;p.y+=p.vy*dt;p.rot+=p.rs*dt;var k=p.age/p.life;
cx.globalAlpha=k<.7?1:(1-k)/.3;var s=p.sc*(k<.1?k/.1:1);
cx.setTransform(dpr*s,0,0,dpr*s,p.x*dpr,p.y*dpr);cx.rotate(p.rot);cx.drawImage(sprite(p.e),-32,-32)}
cx.globalAlpha=1;cx.setTransform(1,0,0,1,0,0);
if(active.length)requestAnimationFrame(frame);else running=false}
document.addEventListener("visibilitychange",function(){if(document.hidden){active.length=0}});
RX.forEach(function(r){counts[r[1]]=0;var c=h("b",{text:"0"});c.style.fontWeight="400";
var b=h("button",{class:"rx","aria-label":"Send "+r[1]+" reaction"},[h("span",{text:r[0]}),h("small",{text:r[1]})]);
b.addEventListener("pointerdown",function(){var pr=$("#player").getBoundingClientRect(),br=b.getBoundingClientRect();
var bx=Math.min(W-30,Math.max(30,br.left+br.width/2-pr.left));spawn(r[0],reduce?3:8,bx);if(sock)sock.emit("rx:send",{i:RX.indexOf(r)})});
$("#rxBar").appendChild(b)});
// remote viewers react too
setInterval(function(){if(sock)return;var r=RX[Math.floor(Math.random()*RX.length)];spawn(r[0],reduce?1:3,30+Math.random()*(W-60))},2200);
var vw=1200+Math.floor(Math.random()*300);
function vwr(){$("#viewers").textContent=vw.toLocaleString()+" watching"}vwr();
setInterval(function(){if(sock)return;vw+=Math.floor(Math.random()*9)-3;vwr()},3000);
function markMine(){qs.forEach(function(q){q.me=mineQ.has(q.id)});renderQ()}
function setQs(list){qs=list.map(function(x){return{id:x.id,t:x.t,v:x.v,ts:x.id,me:mineQ.has(x.id)}});renderQ()}
if(sock){
sock.on("init",function(s){chat.textContent="";s.chat.forEach(function(m){addMsg(m.name,m.text)});mineQ=new Set(s.mineQ);setQs(s.questions);poll.q=s.poll.q;poll.o=s.poll.o;poll.mine=s.mineP;renderAllPolls()});
sock.on("chat:new",function(m){addMsg(m.name===MYNAME?"You":m.name,m.text,m.name===MYNAME)});
sock.on("qna:list",setQs);
sock.on("poll:update",function(p){poll.o=p.o;renderAllPolls()});
sock.on("rx:burst",function(m){var r=RX[m.i];if(r)spawn(r[0],reduce?1:3,30+Math.random()*(W-60))});
sock.on("viewers",function(n){$("#viewers").textContent=n.toLocaleString()+" watching"});
sock.on("disconnect",function(){$("#viewers").textContent="Reconnecting…"});
sock.on("rate_limited",function(){toast("Slow down a little.")});
}
renderNow();

