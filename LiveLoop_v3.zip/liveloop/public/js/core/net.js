// Adapter pattern: modules talk to ONE interface (Emitter + methods); OnlineNet uses the server,
// OfflineNet simulates everything locally (persisted in localStorage) so the demo never breaks.
import { SEED } from "../data.js";
import { store } from "./storage.js";

export class Emitter {
  #handlers = new Map();
  on(event, fn) { if (!this.#handlers.has(event)) this.#handlers.set(event, []); this.#handlers.get(event).push(fn); return this; }
  emit(event, data) { (this.#handlers.get(event) ?? []).forEach(fn => fn(data)); }
}

export class OnlineNet extends Emitter {
  online = true;
  constructor(token) {
    super();
    this.socket = window.io({ auth: { token } });
    const events = { init: "init", "chat:new": "chat", "qna:list": "questions", "poll:update": "poll",
      "poll:open": "pollopen", "rx:burst": "reaction", viewers: "viewers", rate_limited: "limited" };
    for (const [from, to] of Object.entries(events)) this.socket.on(from, data => this.emit(to, data));
    this.socket.on("connect", () => this.emit("status", "online"));
    this.socket.on("disconnect", () => this.emit("status", "reconnecting"));
    this.socket.on("connect_error", err => this.emit(err?.message === "unauthorized" ? "autherror" : "status", "reconnecting"));
  }
  request(event, data) {
    return new Promise(resolve => {
      const timer = setTimeout(() => resolve({ ok: false }), 5000);
      this.socket.emit(event, data, res => { clearTimeout(timer); resolve(res ?? { ok: false }); });
    });
  }
  sendChat(text) { this.socket.emit("chat:send", { text }); }
  ask(text) { return this.request("qna:ask", { text }); }
  vote(id) { return this.request("qna:vote", { id }); }
  pollVote(i) { return this.request("poll:vote", { i }); }
  react(i) { this.socket.emit("rx:send", { i }); }
  setStatus(id, status) { return this.request("mod:status", { id, status }); }
  launchPoll(q, options) { return this.request("mod:poll", { q, options }); }
}

export class OfflineNet extends Emitter {
  online = false;
  constructor(user) {
    super();
    this.user = user;
    this.state = store.get("ll_offline") ?? {
      questions: SEED.questions.map(([t, v], id) => ({ id, t, v, status: "open" })),
      mine: [], mineP: -1, poll: { q: SEED.poll.q, o: SEED.poll.o.map(([l, v]) => ({ l, v })) },
    };
    setTimeout(() => {
      this.emit("init", {
        chat: SEED.botLines.slice(0, 4).map((text, i) => ({ name: SEED.botNames[i], text })),
        questions: this.#open(), poll: this.state.poll, mineQ: this.state.mine, mineP: this.state.mineP,
      });
      this.emit("status", "offline");
      this.#startBots();
    }, 0);
  }
  #open() { return this.state.questions.filter(q => q.status !== "archived"); }
  #save() { store.set("ll_offline", this.state); }
  #startBots() {
    const pick = list => list[Math.floor(Math.random() * list.length)];
    const chat = () => { this.emit("chat", { name: pick(SEED.botNames), text: pick(SEED.botLines) }); setTimeout(chat, 4000 + Math.random() * 5000); };
    setTimeout(chat, 4000);
    setInterval(() => this.emit("reaction", { i: Math.floor(Math.random() * 5) }), 2200);
    setInterval(() => this.emit("viewers", 1200 + Math.floor(Math.random() * 300)), 3000);
    setInterval(() => {
      if (this.state.mineP < 0) return;
      this.state.poll.o[Math.floor(Math.random() * this.state.poll.o.length)].v++;
      this.#save(); this.emit("poll", this.state.poll);
    }, 2500);
    setTimeout(() => this.emit("pollopen", this.state.poll), 15000);
  }
  sendChat(text) { this.emit("chat", { name: this.user.name, text }); }
  async ask(text) {
    const s = this.state, dup = s.questions.find(q => q.t.toLowerCase() === text.toLowerCase());
    const q = dup ?? { id: Date.now(), t: text, v: 0, status: "open" };
    if (!dup) s.questions.push(q);
    if (!s.mine.includes(q.id)) { s.mine.push(q.id); q.v++; }
    this.#save(); this.emit("questions", this.#open());
    return { ok: true, id: q.id };
  }
  async vote(id) {
    const s = this.state, q = s.questions.find(x => x.id === id);
    if (!q) return { ok: false };
    const voted = !s.mine.includes(id);
    s.mine = voted ? [...s.mine, id] : s.mine.filter(x => x !== id);
    q.v += voted ? 1 : -1;
    this.#save(); this.emit("questions", this.#open());
    return { ok: true, voted };
  }
  async pollVote(i) {
    const s = this.state;
    if (s.mineP >= 0 || !s.poll.o[i]) return { ok: false };
    s.mineP = i; s.poll.o[i].v++;
    this.#save(); this.emit("poll", s.poll);
    return { ok: true };
  }
  react() { /* local-only: the reactions module already animates the click */ }
  async setStatus() { return { ok: false }; }
  async launchPoll() { return { ok: false }; }
}
