import test from "node:test";
import assert from "node:assert/strict";
import { sign, verify, checkModPassword } from "../server/auth.js";

const secret = "unit-test-secret";
test("sign + verify round trip", () => {
  const token = sign({ cid: "a1", name: "Ana", role: "mod" }, { secret });
  const p = verify(token, { secret });
  assert.equal(p.name, "Ana"); assert.equal(p.role, "mod");
});
test("tampered or foreign tokens are rejected", () => {
  const token = sign({ cid: "a1", name: "Ana", role: "attendee" }, { secret });
  const [body, sig] = token.split(".");
  const forged = Buffer.from(JSON.stringify({ cid: "a1", name: "Ana", role: "mod", exp: Date.now() + 1e6 })).toString("base64url");
  assert.equal(verify(`${forged}.${sig}`, { secret }), null);
  assert.equal(verify(token, { secret: "other-secret" }), null);
  assert.equal(verify(`${body}.`, { secret }), null);
  for (const bad of [undefined, null, 42, "", "abc", "a.b.c"]) assert.equal(verify(bad, { secret }), null);
});
test("expired tokens are rejected", () => {
  const token = sign({ cid: "a1" }, { secret, ttlMs: 1000, now: 0 });
  assert.ok(verify(token, { secret, now: 500 }));
  assert.equal(verify(token, { secret, now: 2000 }), null);
});
test("moderator password check", () => {
  assert.equal(checkModPassword("right", "right"), true);
  assert.equal(checkModPassword("wrong", "right"), false);
  assert.equal(checkModPassword("", "right"), false);
});
