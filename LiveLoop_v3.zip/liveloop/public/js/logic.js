// Pure, framework-free logic shared by the browser, the server and the unit tests.
export function sanitizeText(s, max = 200) {
  if (typeof s !== "string") return "";
  return s.replace(/<[^>]*>/g, "").replace(/[\u0000-\u001F\u007F]/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
}
export const clean = sanitizeText;

// Largest-remainder method: percentages always sum to exactly 100 (or all 0 with no votes).
export function percentages(votes) {
  const total = votes.reduce((a, b) => a + b, 0);
  if (!total) return votes.map(() => 0);
  const raw = votes.map(v => (v * 100) / total), base = raw.map(Math.floor);
  let rest = 100 - base.reduce((a, b) => a + b, 0);
  raw.map((r, i) => [r - base[i], i]).sort((a, b) => b[0] - a[0]).slice(0, rest).forEach(([, i]) => base[i]++);
  return base;
}

// Most upvotes first; older question wins ties.
export function rankQuestions(list) {
  return list.slice().sort((a, b) => b.v - a.v || a.ts - b.ts);
}

// Whitelisted embeds only: https YouTube / Vimeo. Anything else returns null.
export function parseEmbed(input) {
  let u;
  try { u = new URL(String(input).trim()); } catch { return null; }
  if (u.protocol !== "https:") return null;
  const host = u.hostname.replace(/^www\./, "");
  let id = null;
  if (host === "youtu.be") id = u.pathname.slice(1);
  else if (host === "youtube.com" || host === "m.youtube.com")
    id = u.searchParams.get("v") || (u.pathname.match(/^\/(?:live|embed)\/([\w-]{11})/) || [])[1];
  if (id && /^[\w-]{11}$/.test(id)) return { provider: "youtube", src: `https://www.youtube.com/embed/${id}?autoplay=1&rel=0` };
  if (host === "vimeo.com") {
    const m = u.pathname.match(/^\/(\d+)/);
    if (m) return { provider: "vimeo", src: `https://player.vimeo.com/video/${m[1]}` };
  }
  return null;
}

export const LIMITS = { chat: 200, question: 280, name: 24 };
