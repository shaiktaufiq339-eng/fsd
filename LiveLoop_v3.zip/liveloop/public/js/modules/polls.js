import { $, $$, h } from "../core/dom.js";
import { percentages } from "../logic.js";

export function init({ net }) {
  let poll = { q: "", o: [] }, mine = -1;
  const inline = $("#pollBox"), pop = $("#pollPop"), dlg = $("#pollDlg");

  const vote = async i => {
    if (mine >= 0) return;
    const r = await net.pollVote(i);
    if (r.ok) { mine = i; paintAll(); }
  };
  function paint(el) {
    const signature = poll.q + "|" + poll.o.map(o => o.l).join("|");
    if (el.dataset.sig !== signature) { // rebuild only when the poll itself changes, so bar widths can animate
      el.dataset.sig = signature; el.textContent = "";
      el.append(h("h3", { text: poll.q }),
        ...poll.o.map((o, i) => h("button", { class: "opt", onclick: () => vote(i) }, [h("i"), h("span", { text: o.l }), h("span", { class: "n" })])),
        h("small", { class: "chip hint" }));
    }
    const pct = percentages(poll.o.map(o => o.v)), total = poll.o.reduce((a, o) => a + o.v, 0);
    $$(".opt", el).forEach((b, i) => {
      b.classList.toggle("mine", mine === i);
      $("i", b).style.width = (mine >= 0 ? pct[i] : 0) + "%";
      $(".n", b).textContent = mine >= 0 ? `${pct[i]}% · ${poll.o[i].v}` : "";
    });
    $(".hint", el).textContent = mine < 0 ? `Vote to see live results · ${total} votes` : `Thanks for voting · ${total} votes · results update live`;
  }
  const paintAll = () => { paint(inline); if (dlg.open) paint(pop); };

  net.on("init", s => { poll = s.poll; mine = s.mineP; paintAll(); });
  net.on("poll", p => { poll = p; paintAll(); });
  net.on("pollopen", p => { // a new poll was launched: reset my vote and pop it up
    if (p.q !== poll.q) mine = -1;
    poll = p; paint(inline); paint(pop);
    $("#pdot").style.display = "inline-block";
    if (!dlg.open) dlg.showModal();
  });
  $("#popClose").addEventListener("click", () => dlg.close());
}
