# LiveLoop v2 – HybridHall Hack

Hybrid event livestream app: embedded stream, live chat, upvoted Q&A, live polls, floating reactions, schedule drawer.

## Run
    npm install
    npm start          # http://localhost:3000  (open in several tabs/devices to see real-time sync)
    npm test           # unit tests (Node built-in test runner, no extra deps)

If the Socket.IO server is not reachable (e.g. the page is opened as a static file) the client falls back to the original local simulation.

## Structure
    public/index.html, css/style.css, js/app.js   client (ES module)
    public/js/logic.js                            pure shared logic (sanitize, percentages, ranking, embed parsing)
    server/index.js                               Express + Socket.IO + SQLite (better-sqlite3)
    test/logic.test.js                            unit tests

## Changes made from the evaluation feedback
| Feedback | Change |
|---|---|
| No real backend | Express + Socket.IO server, SQLite persistence for chat, questions, votes and poll tallies |
| Replace bot simulation with real peers | Chat, Q&A votes, poll votes and reactions are broadcast between all connected clients; bots only run in offline mode |
| No XSS sanitization / minimal validation | `sanitizeText` strips tags and control characters and clamps length on both client and server; DOM writes use `textContent`; CSP and nosniff headers; embed URLs are whitelisted (https YouTube / Vimeo only) |
| No automated tests | `test/logic.test.js` covers poll percentages, Q&A ranking, sanitizing and embed parsing |
| Logic tightly coupled to DOM | Pure functions moved to `logic.js` and shared by browser, server and tests |
| Missing runtime error handling | Global error / unhandledrejection handlers with a toast; try/catch and acknowledgements on every socket handler |
| Resilience | Server-side one-vote-per-user constraints, per-socket rate limiting, auto-reconnect with status indicator |
| Build step | `npm run build` (Vite) is configured |
