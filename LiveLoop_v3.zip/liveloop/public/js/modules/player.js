import { $, fmt } from "../core/dom.js";
import { parseEmbed } from "../logic.js";
import { sessions, statusOf } from "../data.js";

export function init({ bus }) {
  let cur = 0;
  const render = () => {
    const s = sessions[cur], st = statusOf(s), next = sessions[cur + 1];
    $("#simT").textContent = s.title;
    $("#simS").textContent = `${s.speaker} · ${s.role}`;
    $("#nowT").textContent = s.title;
    $("#nowS").textContent = `${s.speaker} – ${s.role}. ${s.bio}`;
    $("#nowSt").textContent = st === "live" ? "Live now" : st === "up" ? `Starts in ${fmt(s.start - Date.now())}` : "Completed";
    $("#nowNext").textContent = next ? `Up next: ${next.title} in ${fmt(next.start - Date.now())}` : "This is the final session.";
  };
  bus.on("session", i => { cur = i; render(); });
  setInterval(render, 1000);
  render();

  $("#srcF").addEventListener("submit", e => {
    e.preventDefault();
    $("#player iframe")?.remove();
    const embed = parseEmbed($("#srcI").value), sim = $("#sim");
    if (!embed) { sim.style.display = "flex"; $("#simS").textContent = "Couldn’t read that link. Try a YouTube or Vimeo URL."; return; }
    sim.style.display = "none";
    const frame = document.createElement("iframe");
    frame.src = embed.src; frame.title = "Event livestream"; frame.allowFullscreen = true;
    frame.allow = "autoplay; fullscreen; picture-in-picture";
    $("#player").insertBefore(frame, $("#fx"));
  });
}
