import { $, toast, clock } from "../core/dom.js";
import { store } from "../core/storage.js";
import { EVENT, sessions } from "../data.js";

/** Private notepad: autosaves to localStorage and downloads as a .txt file. Notes never leave the device. */
export function init({ bus }) {
  const area = $("#notes"), status = $("#noteStatus"), KEY = `ll_notes_${EVENT.id}`;
  let cur = 0, timer;
  area.value = store.get(KEY, "");
  bus.on("session", i => { cur = i; });

  area.addEventListener("input", () => {
    status.textContent = "Saving…";
    clearTimeout(timer);
    timer = setTimeout(() => { status.textContent = store.set(KEY, area.value) ? "Saved on this device" : "Storage full – please download your notes"; }, 500);
  });
  $("#stamp").addEventListener("click", () => {
    const tag = `[${clock(new Date())} · ${sessions[cur].speaker}] `;
    const pos = area.selectionStart ?? area.value.length;
    area.setRangeText(tag, pos, area.selectionEnd ?? pos, "end");
    area.focus(); area.dispatchEvent(new Event("input"));
  });
  $("#dl").addEventListener("click", () => {
    if (!area.value.trim()) { toast("Write something first."); return; }
    const url = URL.createObjectURL(new Blob([`${EVENT.title} – my notes\n\n${area.value}\n`], { type: "text/plain" }));
    const a = Object.assign(document.createElement("a"), { href: url, download: "GlobalTechSummit2026-notes.txt" });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
}
