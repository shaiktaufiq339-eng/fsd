# LiveLoop v3 – HybridHall Hack

Hybrid event livestream app for "Global Tech Summit 2026": embedded stream, live chat, upvoted Q&A,
live polls, floating reactions, schedule drawer, private notes, and a moderator console.

## Run
    npm install
    npm start            # http://localhost:3000  (open in several tabs / devices to see real-time sync)
    npm test             # unit tests (Node built-in runner, no extra dependencies)

Optional environment variables: `PORT`, `DB_FILE`, `SESSION_SECRET` (set a fixed value in production),
`MOD_PASSWORD` (default `moderator123`, change it).

Sign in with any display name. Enter the moderator password to join as a moderator (extra "Mod" tab, plus
"Answered live" / "Archive" buttons on every question, and the poll launcher).
If the Node server is not running (page opened as a static file) the app switches to an offline demo mode.

## Architecture (3 tiers)
    Presentation   public/index.html, css/style.css, js/main.js + js/modules/*  (one ES module per feature)
    Application    server/index.js   Express + Socket.IO: login, sessions, validation, rate limiting, broadcasts
                   server/auth.js    signed session tokens (HMAC-SHA256), moderator password check
    Data           server/db.js      SQLite (better-sqlite3): chat, questions, votes, poll tallies
    Shared         public/js/logic.js  pure functions used by browser, server and tests
    Client core    js/core/net.js    Adapter pattern: OnlineNet (server) and OfflineNet (local) share one interface
                   js/core/storage.js, dom.js, auth.js
    Tests          test/logic.test.js, test/auth.test.js

## How the evaluation feedback was addressed
| Feedback (attempts 1 and 2) | Change |
|---|---|
| Node.js/Express backend and database missing | Express + Socket.IO server with SQLite persistence (`server/`) |
| Chat/polls not live across sessions | Chat, Q&A votes, poll votes, reactions and viewer count broadcast over WebSockets |
| Authentication and session management missing | `/api/login` issues signed, expiring session tokens; sockets are rejected without a valid token; roles (attendee / mod) are enforced on the server; login rate limiting |
| No formal XSS sanitization | `sanitizeText` strips tags/control characters on client AND server; all DOM output uses `textContent` (no `innerHTML` anywhere); strict CSP; embeds limited to https YouTube/Vimeo |
| No validation of message/question length | `LIMITS` (chat 200, question 280, name 24) enforced on both sides, plus minimum question length |
| Single file, no separation of concerns | HTML, CSS and JS separated; JS split into core, data and 8 feature modules; business logic isolated in `logic.js` |
| No design patterns | Adapter (online/offline net), event emitter / pub-sub bus, repository (db.js), module `init(ctx)` pattern |
| No automated tests | 10 unit tests: poll percentages, ranking, sanitizing, embed parsing, token signing/tampering/expiry, password check |
| Data lost on refresh | Notes, theme, session, poll vote and offline demo state persist in localStorage |
| Limited error handling | Global error handlers + toasts, safe storage wrapper, try/catch + acks on every socket handler, request timeouts, auto-reconnect indicator |
| Innovation / depth | Canvas particle engine with pooling and sprite cache, FLIP re-ranking animation, largest-remainder poll math, moderator console, dual-mode (online/offline) adapter |

## Notes
- `npm run build` (Vite) is configured but optional; the app runs without a build step.
- Moderator actions are checked on the server using the signed token, never trusting the browser.
