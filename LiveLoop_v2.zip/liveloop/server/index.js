import express from "express";
import http from "http";
import path from "path";
import { fileURLToPath } from "url";
import { Server } from "socket.io";
import Database from "better-sqlite3";
import { sanitizeText } from "../public/js/logic.js";

const dir = path.dirname(fileURLToPath(import.meta.url));
const db = new Database(process.env.DB_FILE || path.join(dir, "liveloop.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS chat(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, text TEXT, ts TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT UNIQUE COLLATE NOCASE, votes INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS qvotes(qid INTEGER, cid TEXT, PRIMARY KEY(qid, cid));
CREATE TABLE IF NOT EXISTS options(idx INTEGER PRIMARY KEY, label TEXT, votes INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS pvotes(cid TEXT PRIMARY KEY, idx INTEGER);`);
if (!db.prepare("SELECT COUNT(*) n FROM questions").get().n) {
  const q = db.prepare("INSERT INTO questions(text,votes) VALUES(?,?)");
  [["How should small teams adopt AI safely?", 24], ["Is multi-cloud worth the operational complexity?", 17],
   ["What is the realistic timeline for Quantum Error Correction at scale?", 11],
   ["Which Web3 attack vector is most underestimated?", 6], ["Will the slides be shared after the session?", 3]].forEach(r => q.run(...r));
  const o = db.prepare("INSERT INTO options(idx,label,votes) VALUES(?,?,?)");
  [["AWS", 42], ["Azure", 31], ["Google Cloud", 19], ["Other", 8]].forEach((r, i) => o.run(i, ...r));
}
const POLL_Q = "What is your primary cloud provider?";
const questions = () => db.prepare("SELECT id, text t, votes v FROM questions ORDER BY votes DESC, id").all();
const pollState = () => ({ q: POLL_Q, o: db.prepare("SELECT label l, votes v FROM options ORDER BY idx").all() });

const app = express();
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("Content-Security-Policy",
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self' ws: wss:; frame-src https://www.youtube.com https://player.vimeo.com");
  res.setHeader("X-Content-Type-Options", "nosniff");
  next();
});
app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use(express.static(path.join(dir, "../public")));

const server = http.createServer(app);
const io = new Server(server);

// Simple per-socket sliding-window rate limiter.
function limited(socket, key, max, ms) {
  const now = Date.now(), b = ((socket.data.rl ??= {})[key] ??= []);
  while (b.length && now - b[0] > ms) b.shift();
  if (b.length >= max) { socket.emit("rate_limited"); return true; }
  b.push(now); return false;
}
const ack = (cb, v) => typeof cb === "function" && cb(v);

io.on("connection", socket => {
  const cid = String(socket.handshake.auth?.cid || "").replace(/[^\w-]/g, "").slice(0, 40) || socket.id;
  const mineQ = db.prepare("SELECT qid FROM qvotes WHERE cid=?").all(cid).map(r => r.qid);
  const mineP = db.prepare("SELECT idx FROM pvotes WHERE cid=?").get(cid)?.idx ?? -1;
  socket.emit("init", {
    chat: db.prepare("SELECT name, text FROM chat ORDER BY id DESC LIMIT 50").all().reverse(),
    questions: questions(), poll: pollState(), mineQ, mineP,
  });
  io.emit("viewers", io.engine.clientsCount);

  socket.on("chat:send", d => {
    try {
      const text = sanitizeText(d?.text, 200), name = sanitizeText(d?.name, 24) || "Guest";
      if (!text || limited(socket, "chat", 5, 10000)) return;
      db.prepare("INSERT INTO chat(name,text) VALUES(?,?)").run(name, text);
      io.emit("chat:new", { name, text });
    } catch (e) { console.error("chat:send", e); }
  });

  socket.on("qna:ask", (d, cb) => {
    try {
      const text = sanitizeText(d?.text, 280);
      if (!text || limited(socket, "qna", 3, 10000)) return ack(cb, { ok: false });
      let q = db.prepare("SELECT id FROM questions WHERE text=?").get(text);
      if (!q) q = { id: db.prepare("INSERT INTO questions(text,votes) VALUES(?,0)").run(text).lastInsertRowid };
      const added = db.prepare("INSERT OR IGNORE INTO qvotes(qid,cid) VALUES(?,?)").run(q.id, cid).changes;
      if (added) db.prepare("UPDATE questions SET votes=votes+1 WHERE id=?").run(q.id);
      ack(cb, { ok: true, id: Number(q.id) });
      io.emit("qna:list", questions());
    } catch (e) { console.error("qna:ask", e); ack(cb, { ok: false }); }
  });

  socket.on("qna:vote", (d, cb) => {
    try {
      const id = Number(d?.id);
      if (!Number.isInteger(id) || limited(socket, "vote", 20, 10000)) return ack(cb, { ok: false });
      const toggle = db.transaction(() => {
        if (!db.prepare("SELECT 1 FROM questions WHERE id=?").get(id)) return null;
        const had = db.prepare("DELETE FROM qvotes WHERE qid=? AND cid=?").run(id, cid).changes;
        if (!had) db.prepare("INSERT INTO qvotes(qid,cid) VALUES(?,?)").run(id, cid);
        db.prepare("UPDATE questions SET votes=votes+? WHERE id=?").run(had ? -1 : 1, id);
        return !had;
      });
      const voted = toggle();
      if (voted === null) return ack(cb, { ok: false });
      ack(cb, { ok: true, voted });
      io.emit("qna:list", questions());
    } catch (e) { console.error("qna:vote", e); ack(cb, { ok: false }); }
  });

  socket.on("poll:vote", (d, cb) => {
    try {
      const i = Number(d?.i);
      const exists = db.prepare("SELECT 1 FROM options WHERE idx=?").get(i);
      if (!Number.isInteger(i) || !exists) return ack(cb, { ok: false });
      const added = db.prepare("INSERT OR IGNORE INTO pvotes(cid,idx) VALUES(?,?)").run(cid, i).changes;
      if (!added) return ack(cb, { ok: false });
      db.prepare("UPDATE options SET votes=votes+1 WHERE idx=?").run(i);
      ack(cb, { ok: true });
      io.emit("poll:update", pollState());
    } catch (e) { console.error("poll:vote", e); ack(cb, { ok: false }); }
  });

  socket.on("rx:send", d => {
    const i = Number(d?.i);
    if (Number.isInteger(i) && i >= 0 && i < 5 && !limited(socket, "rx", 30, 1000)) socket.broadcast.emit("rx:burst", { i });
  });

  socket.on("disconnect", () => io.emit("viewers", io.engine.clientsCount));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`LiveLoop running at http://localhost:${PORT}`));
