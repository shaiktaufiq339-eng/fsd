import { $, $$, toast } from "./core/dom.js";
import { store } from "./core/storage.js";
import { Emitter, OnlineNet, OfflineNet } from "./core/net.js";
import { login, logout } from "./core/auth.js";
import * as player from "./modules/player.js";
import * as schedule from "./modules/schedule.js";
import * as chat from "./modules/chat.js";
import * as qna from "./modules/qna.js";
import * as polls from "./modules/polls.js";
import * as reactions from "./modules/reactions.js";
import * as notes from "./modules/notes.js";
import * as moderator from "./modules/moderator.js";

window.addEventListener("error", () => toast("Something went wrong, but LiveLoop is still running."));
window.addEventListener("unhandledrejection", () => toast("A request failed. Please try again."));

function setupTabs() {
  $$(".tabs button").forEach(btn => btn.addEventListener("click", () => {
    $$(".tabs button").forEach(b => b.setAttribute("aria-selected", String(b === btn)));
    $$(".panel").forEach(p => p.classList.toggle("on", p.id === `p-${btn.dataset.t}`));
    if (btn.dataset.t === "poll") $("#pdot").style.display = "none";
  }));
}
function setupTheme() {
  const root = document.documentElement, saved = store.get("ll_theme");
  if (saved) root.dataset.theme = saved;
  $("#themeBtn").addEventListener("click", () => {
    const next = getComputedStyle(root).colorScheme === "dark" ? "light" : "dark";
    root.dataset.theme = next; store.set("ll_theme", next);
  });
}

async function boot() {
  const serverAvailable = typeof window.io === "function"; // socket.io client is only served by our Node server
  let session = store.get("ll_session");
  if (serverAvailable && !session) session = await login();
  if (!serverAvailable) {
    const name = store.get("ll_name") ?? `Guest-${Math.random().toString(36).slice(2, 6)}`;
    store.set("ll_name", name); session = { name, role: "attendee" };
  }
  const net = serverAvailable ? new OnlineNet(session.token) : new OfflineNet(session);
  const ctx = { net, session, bus: new Emitter() };

  $("#who").textContent = session.role === "mod" ? `${session.name} (moderator)` : session.name;
  if (serverAvailable) { $("#logoutBtn").hidden = false; $("#logoutBtn").addEventListener("click", logout); }
  net.on("viewers", n => { $("#viewers").textContent = `${Number(n).toLocaleString()} watching`; });
  net.on("status", s => { if (s === "reconnecting") $("#viewers").textContent = "Reconnecting…"; });
  net.on("limited", () => toast("Slow down a little."));
  net.on("autherror", logout); // expired or invalid session -> sign in again

  setupTabs(); setupTheme();
  [player, schedule, chat, qna, polls, reactions, notes, moderator].forEach(m => m.init(ctx));
}
boot();
