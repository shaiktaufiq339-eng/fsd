import { $, h } from "../core/dom.js";

const REACTIONS = [["👏", "Clap"], ["❤️", "Heart"], ["🔥", "Fire"], ["🤯", "Mindblown"], ["🚀", "Rocket"]];
const MAX_PARTICLES = 250;

/** Canvas particle system: pooled objects, cached emoji sprites, one rAF loop that stops when idle. */
export function init({ net }) {
  const canvas = $("#fx"), ctx = canvas.getContext("2d");
  const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const sprites = new Map(), active = [], pool = [];
  let W = 0, H = 0, dpr = 1, running = false, last = 0;

  const sprite = emoji => {
    if (!sprites.has(emoji)) {
      const c = document.createElement("canvas"); c.width = c.height = 64;
      const g = c.getContext("2d"); g.font = "48px serif"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(emoji, 32, 36);
      sprites.set(emoji, c);
    }
    return sprites.get(emoji);
  };
  new ResizeObserver(() => { const r = canvas.getBoundingClientRect(); dpr = window.devicePixelRatio || 1; W = r.width; H = r.height; canvas.width = W * dpr; canvas.height = H * dpr; }).observe(canvas);

  function spawn(emoji, count, x) {
    for (let i = 0; i < count && active.length < MAX_PARTICLES; i++) {
      const p = pool.pop() ?? {};
      Object.assign(p, { emoji, x: x + (Math.random() - 0.5) * 60, y: H - 20, vx: (Math.random() - 0.5) * 80, vy: -(120 + Math.random() * 140),
        age: 0, life: 1.8 + Math.random() * 1.2, rot: Math.random() - 0.5, spin: (Math.random() - 0.5) * 2,
        scale: 0.5 + Math.random() * 0.6, phase: Math.random() * 6, freq: 3 + Math.random() * 3 });
      active.push(p);
    }
    if (!running) { running = true; last = performance.now(); requestAnimationFrame(frame); }
  }
  function frame(now) {
    const dt = Math.min((now - last) / 1000, 0.05); last = now;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
    for (let i = active.length - 1; i >= 0; i--) {
      const p = active[i]; p.age += dt;
      if (p.age >= p.life) { pool.push(active.splice(i, 1)[0]); continue; }
      p.x += (p.vx + Math.sin(p.age * p.freq + p.phase) * 40) * dt; p.y += p.vy * dt; p.rot += p.spin * dt;
      const k = p.age / p.life, s = p.scale * (k < 0.1 ? k / 0.1 : 1);
      ctx.globalAlpha = k < 0.7 ? 1 : (1 - k) / 0.3;
      ctx.setTransform(dpr * s, 0, 0, dpr * s, p.x * dpr, p.y * dpr); ctx.rotate(p.rot);
      ctx.drawImage(sprite(p.emoji), -32, -32);
    }
    ctx.globalAlpha = 1; ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (active.length) requestAnimationFrame(frame); else running = false;
  }
  document.addEventListener("visibilitychange", () => { if (document.hidden) active.length = 0; });

  REACTIONS.forEach(([emoji, name], i) => {
    const btn = h("button", { class: "rx", "aria-label": `Send ${name} reaction` }, [h("span", { text: emoji }), h("small", { text: name })]);
    btn.addEventListener("pointerdown", () => {
      const p = $("#player").getBoundingClientRect(), b = btn.getBoundingClientRect();
      spawn(emoji, reduceMotion ? 3 : 8, Math.min(W - 30, Math.max(30, b.left + b.width / 2 - p.left)));
      net.react(i);
    });
    $("#rxBar").append(btn);
  });
  net.on("reaction", ({ i }) => { const r = REACTIONS[i]; if (r) spawn(r[0], reduceMotion ? 1 : 3, 30 + Math.random() * Math.max(0, W - 60)); });
}
