import { $, toast } from "../core/dom.js";
import { sanitizeText } from "../logic.js";

/** Moderator console (role "mod" only; the server re-checks the role on every action). */
export function init({ net, session }) {
  if (session.role !== "mod") return;
  $("#modTab").hidden = false;
  $("#modPollF").addEventListener("submit", async e => {
    e.preventDefault();
    const q = sanitizeText($("#modQ").value, 120);
    const options = $("#modOpts").value.split(",").map(o => sanitizeText(o, 40)).filter(Boolean);
    if (!q || options.length < 2 || options.length > 6) { toast("Enter a question and 2–6 comma-separated options."); return; }
    const r = await net.launchPoll(q, options);
    toast(r.ok ? "Poll launched to all attendees." : "Couldn’t launch the poll.");
    if (r.ok) e.target.reset();
  });
}
