import express from "express";
import http from "http";
import path from "path";
import crypto from "node:crypto";
import { fileURLToPath } from "url";
import { Server } from "socket.io";
import { sanitizeText, LIMITS } from "../public/js/logic.js";
import { sign, verify, checkModPassword } from "./auth.js";
import { openDb } from "./db.js";

const dir = path.dirname(fileURLToPath(import.meta.url));
const db = openDb(process.env.DB_FILE || path.join(dir, "liveloop.db"));

// ---------- HTTP: security headers, static files, login ----------
const app = express();
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("Content-Security-Policy",
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self' ws: wss:; frame-src https://www.youtube.com https://player.vimeo.com; frame-ancestors 'self'");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  next();
});
app.use(express.json({ limit: "2kb" }));
app.use(express.static(path.join(dir, "../public")));
app.get("/api/health", (req, res) => res.json({ ok: true }));

const attempts = new Map(); // ip -> recent login timestamps (brute-force protection)
app.post("/api/login", (req, res) => {
  const now = Date.now(), recent = (attempts.get(req.ip) ?? []).filter(t => now - t < 60000);
  attempts.set(req.ip, [...recent, now]);
  if (recent.length >= 10) return res.status(429).json({ error: "Too many attempts. Wait a minute." });
  const name = sanitizeText(req.body?.name, LIMITS.name), password = String(req.body?.password ?? "");
  if (name.length < 2) return res.status(400).json({ error: "Name must be 2–24 characters." });
  let role = "attendee";
  if (password) {
    if (!checkModPassword(password)) return res.status(401).json({ error: "Wrong moderator password." });
    role = "mod";
  }
  const cid = crypto.randomUUID();
  res.json({ token: sign({ cid, name, role }), name, role });
});

// ---------- Realtime ----------
const server = http.createServer(app);
const io = new Server(server);

io.use((socket, next) => {
  const user = verify(socket.handshake.auth?.token);
  if (!user) return next(new Error("unauthorized"));
  socket.data.user = user;
  next();
});

function limited(socket, key, max, ms) { // sliding-window rate limiter per socket
  const now = Date.now(), hits = ((socket.data.rl ??= {})[key] ??= []);
  while (hits.length && now - hits[0] > ms) hits.shift();
  if (hits.length >= max) { socket.emit("rate_limited"); return true; }
  hits.push(now);
  return false;
}
const reply = (cb, value) => { if (typeof cb === "function") cb(value); };

io.on("connection", socket => {
  const { cid, name, role } = socket.data.user;
  socket.emit("init", { chat: db.recentChat(), questions: db.questions(), poll: db.poll(), mineQ: db.myQuestionVotes(cid), mineP: db.myPollVote(cid) });
  io.emit("viewers", io.engine.clientsCount);

  const on = (event, handler) => socket.on(event, (data, cb) => {
    try { handler(data, cb); } catch (err) { console.error(event, err); reply(cb, { ok: false }); }
  });

  on("chat:send", d => {
    const text = sanitizeText(d?.text, LIMITS.chat);
    if (!text || limited(socket, "chat", 5, 10000)) return;
    db.addChat(name, text);
    io.emit("chat:new", { name, text });
  });
  on("qna:ask", (d, cb) => {
    const text = sanitizeText(d?.text, LIMITS.question);
    if (text.length < 5 || limited(socket, "ask", 3, 10000)) return reply(cb, { ok: false });
    const id = db.ask(text, cid);
    reply(cb, { ok: true, id });
    io.emit("qna:list", db.questions());
  });
  on("qna:vote", (d, cb) => {
    const id = Number(d?.id);
    if (!Number.isInteger(id) || limited(socket, "vote", 20, 10000)) return reply(cb, { ok: false });
    const voted = db.toggleVote(id, cid);
    if (voted === null) return reply(cb, { ok: false });
    reply(cb, { ok: true, voted });
    io.emit("qna:list", db.questions());
  });
  on("poll:vote", (d, cb) => {
    const i = Number(d?.i);
    if (!Number.isInteger(i) || !db.castVote(cid, i)) return reply(cb, { ok: false });
    reply(cb, { ok: true });
    io.emit("poll:update", db.poll());
  });
  on("rx:send", d => {
    const i = Number(d?.i);
    if (Number.isInteger(i) && i >= 0 && i < 5 && !limited(socket, "rx", 30, 1000)) socket.broadcast.emit("rx:burst", { i });
  });

  // Moderator-only actions: the role comes from the signed token, never from the client's say-so.
  on("mod:status", (d, cb) => {
    const id = Number(d?.id), status = d?.status;
    if (role !== "mod" || !Number.isInteger(id) || !["open", "answered", "archived"].includes(status)) return reply(cb, { ok: false });
    reply(cb, { ok: db.setStatus(id, status) });
    io.emit("qna:list", db.questions());
  });
  on("mod:poll", (d, cb) => {
    const q = sanitizeText(d?.q, 120);
    const labels = Array.isArray(d?.options) ? d.options.map(o => sanitizeText(o, 40)).filter(Boolean) : [];
    if (role !== "mod" || !q || labels.length < 2 || labels.length > 6) return reply(cb, { ok: false });
    db.launchPoll(q, labels);
    reply(cb, { ok: true });
    io.emit("poll:open", db.poll());
  });

  socket.on("disconnect", () => io.emit("viewers", io.engine.clientsCount));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`LiveLoop running at http://localhost:${PORT}`));
