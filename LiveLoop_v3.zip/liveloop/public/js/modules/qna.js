import { $, $$, h, toast } from "../core/dom.js";
import { sanitizeText, rankQuestions, LIMITS } from "../logic.js";

export function init({ net, session }) {
  const box = $("#qList"), isMod = session.role === "mod";
  let questions = [], mine = new Set(), filter = "open";

  const card = q => {
    const up = h("button", { class: `up${mine.has(q.id) ? " on" : ""}`, "aria-label": "Upvote question", "aria-pressed": String(mine.has(q.id)) }, [h("span", { text: "▲" }), h("b", { text: q.v })]);
    up.addEventListener("click", async () => {
      const r = await net.vote(q.id);
      if (r.ok) { r.voted ? mine.add(q.id) : mine.delete(q.id); render(); }
    });
    const kids = [up, h("p", { text: q.t })];
    if (isMod && q.status === "open") {
      kids.push(h("div", { class: "modbtns" }, [
        h("button", { class: "btn", text: "Answered live", onclick: () => net.setStatus(q.id, "answered") }),
        h("button", { class: "btn", text: "Archive", onclick: () => net.setStatus(q.id, "archived") }),
      ]));
    }
    return h("div", { class: "q", "data-id": q.id }, kids);
  };

  function render() {
    const before = new Map($$(".q", box).map(el => [el.dataset.id, el.getBoundingClientRect().top]));
    box.textContent = "";
    const shown = rankQuestions(questions.filter(q => q.status === filter));
    shown.forEach(q => box.append(card(q)));
    if (!shown.length) box.append(h("p", { class: "chip", text: filter === "open" ? "No open questions yet. Ask the first one!" : "No answered questions yet." }));
    $$(".q", box).forEach(el => { // FLIP: animate cards from their old position to the new rank
      const old = before.get(el.dataset.id);
      if (old === undefined) return;
      const dy = old - el.getBoundingClientRect().top;
      if (!dy) return;
      el.style.transition = "none"; el.style.transform = `translateY(${dy}px)`;
      requestAnimationFrame(() => requestAnimationFrame(() => { el.style.transition = ""; el.style.transform = ""; }));
    });
  }
  const setQuestions = list => { questions = list.map(q => ({ ...q, ts: q.id })); render(); };

  $$("#qFilter button").forEach(b => b.addEventListener("click", () => {
    filter = b.dataset.f;
    $$("#qFilter button").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    render();
  }));
  $("#qF").addEventListener("submit", async e => {
    e.preventDefault();
    const input = $("#qI"), text = sanitizeText(input.value, LIMITS.question);
    if (text.length < 5) { toast("Please write a complete question (5+ characters)."); return; }
    input.value = "";
    const r = await net.ask(text);
    if (r.ok) { mine.add(r.id); render(); } else toast("Couldn’t post your question. Please try again.");
  });
  net.on("init", s => { mine = new Set(s.mineQ); setQuestions(s.questions); });
  net.on("questions", setQuestions);
}
