import { $, h, fmt, clock } from "../core/dom.js";
import { sessions, statusOf } from "../data.js";

export function init({ bus }) {
  const drawer = $("#drawer"), box = $("#sched");
  const label = s => { const st = statusOf(s); return st === "live" ? "Live now" : st === "up" ? `Starts in ${fmt(s.start - Date.now())}` : "Completed"; };
  const cards = sessions.map((s, i) => {
    const status = h("span", { class: "st" });
    const head = h("button", { "aria-expanded": "false" }, [status, h("b", { text: s.title }), h("span", { class: "chip", text: `${s.speaker} · ${clock(new Date(s.start))}` })]);
    const watch = h("button", { class: "btn primary", text: "Watch this session", onclick: () => { bus.emit("session", i); drawer.classList.remove("on"); } });
    const card = h("div", { class: "sess" }, [head, h("div", { class: "body" }, [h("p", { text: `${s.role}. ${s.bio}` }), watch])]);
    head.addEventListener("click", () => {
      const open = !card.classList.contains("open");
      cards.forEach(c => { c.card.classList.remove("open"); c.head.setAttribute("aria-expanded", "false"); });
      card.classList.toggle("open", open); head.setAttribute("aria-expanded", String(open));
    });
    box.append(card);
    return { s, status, card, head };
  });
  const tick = () => cards.forEach(({ s, status }) => { status.textContent = label(s); status.className = `st ${statusOf(s)}`; });
  setInterval(tick, 1000); tick();
  $("#schedBtn").addEventListener("click", () => drawer.classList.add("on"));
  $("#closeD").addEventListener("click", () => drawer.classList.remove("on"));
}
