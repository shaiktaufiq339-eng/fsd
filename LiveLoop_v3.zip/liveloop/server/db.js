// Data layer: every SQL statement lives here, so index.js only deals with networking and rules.
import Database from "better-sqlite3";
import { SEED } from "../public/js/data.js";

const SCHEMA = `
CREATE TABLE IF NOT EXISTS chat(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, text TEXT, ts TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT UNIQUE COLLATE NOCASE, votes INTEGER DEFAULT 0, status TEXT DEFAULT 'open');
CREATE TABLE IF NOT EXISTS qvotes(qid INTEGER, cid TEXT, PRIMARY KEY(qid, cid));
CREATE TABLE IF NOT EXISTS options(idx INTEGER PRIMARY KEY, label TEXT, votes INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS pvotes(cid TEXT PRIMARY KEY, idx INTEGER);
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);`;

export function openDb(file) {
  const db = new Database(file);
  db.pragma("journal_mode = WAL");
  db.exec(SCHEMA);
  const q = sql => db.prepare(sql);

  const repo = {
    recentChat: (n = 50) => q("SELECT name, text FROM chat ORDER BY id DESC LIMIT ?").all(n).reverse(),
    addChat: (name, text) => q("INSERT INTO chat(name,text) VALUES(?,?)").run(name, text),

    questions: () => q("SELECT id, text t, votes v, status FROM questions WHERE status != 'archived' ORDER BY votes DESC, id").all(),
    myQuestionVotes: cid => q("SELECT qid FROM qvotes WHERE cid=?").all(cid).map(r => r.qid),
    /** Creates the question (or finds the duplicate) and gives the asker one vote. */
    ask: db.transaction((text, cid) => {
      let row = q("SELECT id FROM questions WHERE text=?").get(text);
      const id = row ? row.id : Number(q("INSERT INTO questions(text,votes) VALUES(?,0)").run(text).lastInsertRowid);
      if (q("INSERT OR IGNORE INTO qvotes(qid,cid) VALUES(?,?)").run(id, cid).changes)
        q("UPDATE questions SET votes=votes+1 WHERE id=?").run(id);
      return id;
    }),
    /** Toggles this user's upvote. Returns true (voted), false (vote removed) or null (no such question). */
    toggleVote: db.transaction((id, cid) => {
      if (!q("SELECT 1 FROM questions WHERE id=?").get(id)) return null;
      const removed = q("DELETE FROM qvotes WHERE qid=? AND cid=?").run(id, cid).changes;
      if (!removed) q("INSERT INTO qvotes(qid,cid) VALUES(?,?)").run(id, cid);
      q("UPDATE questions SET votes=votes+? WHERE id=?").run(removed ? -1 : 1, id);
      return !removed;
    }),
    setStatus: (id, status) => q("UPDATE questions SET status=? WHERE id=?").run(status, id).changes > 0,

    poll: () => ({ q: q("SELECT v FROM meta WHERE k='poll_q'").get()?.v ?? "", o: q("SELECT label l, votes v FROM options ORDER BY idx").all() }),
    myPollVote: cid => q("SELECT idx FROM pvotes WHERE cid=?").get(cid)?.idx ?? -1,
    castVote: db.transaction((cid, i) => {
      if (!q("SELECT 1 FROM options WHERE idx=?").get(i)) return false;
      if (!q("INSERT OR IGNORE INTO pvotes(cid,idx) VALUES(?,?)").run(cid, i).changes) return false;
      q("UPDATE options SET votes=votes+1 WHERE idx=?").run(i);
      return true;
    }),
    launchPoll: db.transaction((question, labels) => {
      q("DELETE FROM options").run(); q("DELETE FROM pvotes").run();
      labels.forEach((l, i) => q("INSERT INTO options(idx,label,votes) VALUES(?,?,0)").run(i, l));
      q("INSERT OR REPLACE INTO meta(k,v) VALUES('poll_q',?)").run(question);
    }),
  };

  if (!q("SELECT COUNT(*) n FROM questions").get().n) { // first run: seed demo data
    SEED.questions.forEach(([t, v]) => q("INSERT INTO questions(text,votes) VALUES(?,?)").run(t, v));
    repo.launchPoll(SEED.poll.q, SEED.poll.o.map(([l]) => l));
    SEED.poll.o.forEach(([, v], i) => q("UPDATE options SET votes=? WHERE idx=?").run(v, i));
  }
  return repo;
}
