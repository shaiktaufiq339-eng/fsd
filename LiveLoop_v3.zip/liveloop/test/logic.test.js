import test from "node:test";
import assert from "node:assert/strict";
import { percentages, rankQuestions, sanitizeText, parseEmbed } from "../public/js/logic.js";

test("percentages always sum to 100", () => {
  for (let n = 0; n < 500; n++) {
    const v = Array.from({ length: 2 + (n % 5) }, () => Math.floor(Math.random() * 100));
    if (v.every(x => x === 0)) continue;
    assert.equal(percentages(v).reduce((a, b) => a + b, 0), 100);
  }
});
test("percentages: known cases", () => {
  assert.deepEqual(percentages([0, 0, 0]), [0, 0, 0]);
  assert.deepEqual(percentages([1, 1, 1]), [34, 33, 33]);
  assert.deepEqual(percentages([42, 31, 19, 8]), [42, 31, 19, 8]);
  assert.deepEqual(percentages([5]), [100]);
});
test("rankQuestions: votes desc, older first on ties, input not mutated", () => {
  const list = [{ id: 1, v: 3, ts: 1 }, { id: 2, v: 9, ts: 2 }, { id: 3, v: 3, ts: 0 }];
  assert.deepEqual(rankQuestions(list).map(q => q.id), [2, 3, 1]);
  assert.equal(list[0].id, 1);
});
test("sanitizeText strips tags, control chars and clamps length", () => {
  assert.equal(sanitizeText("<img src=x onerror=alert(1)>Hi\u0000  there"), "Hi there");
  assert.equal(sanitizeText("   "), "");
  assert.equal(sanitizeText(42), "");
  assert.equal(sanitizeText("a".repeat(500), 200).length, 200);
});
test("parseEmbed accepts YouTube/Vimeo https links", () => {
  assert.equal(parseEmbed("https://www.youtube.com/watch?v=dQw4w9WgXcQ").src, "https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&rel=0");
  assert.equal(parseEmbed("https://youtu.be/dQw4w9WgXcQ").provider, "youtube");
  assert.equal(parseEmbed("https://www.youtube.com/live/dQw4w9WgXcQ").provider, "youtube");
  assert.equal(parseEmbed("https://vimeo.com/76979871").src, "https://player.vimeo.com/video/76979871");
});
test("parseEmbed rejects unsafe or unknown links", () => {
  for (const bad of ["javascript:alert(1)", "http://youtu.be/dQw4w9WgXcQ", "https://youtube.com.evil.com/watch?v=dQw4w9WgXcQ",
    "https://example.com/video", "not a url", "", "https://vimeo.com/abc"]) assert.equal(parseEmbed(bad), null, bad);
});
