// Stateless signed sessions (HMAC-SHA256) using only Node's crypto module.
import crypto from "node:crypto";

const DEFAULT_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex");
const b64 = buf => Buffer.from(buf).toString("base64url");
const mac = (data, secret) => crypto.createHmac("sha256", secret).update(data).digest("base64url");

export function sign(payload, { ttlMs = 8 * 3600e3, secret = DEFAULT_SECRET, now = Date.now() } = {}) {
  const body = b64(JSON.stringify({ ...payload, exp: now + ttlMs }));
  return `${body}.${mac(body, secret)}`;
}

/** Returns the payload, or null if the token is malformed, tampered with or expired. */
export function verify(token, { secret = DEFAULT_SECRET, now = Date.now() } = {}) {
  if (typeof token !== "string") return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = Buffer.from(mac(body, secret)), given = Buffer.from(sig);
  if (expected.length !== given.length || !crypto.timingSafeEqual(expected, given)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString());
    return payload.exp > now ? payload : null;
  } catch { return null; }
}

export function checkModPassword(input, expected = process.env.MOD_PASSWORD || "moderator123") {
  const hash = s => crypto.createHash("sha256").update(String(s)).digest();
  return crypto.timingSafeEqual(hash(input), hash(expected));
}
